"""Independent offline review probes. No real provider calls; writes only local evidence."""
import asyncio, csv, hashlib, itertools, json, platform, re, sys
from pathlib import Path
import pandas as pd
import yaml
from bs4 import BeautifulSoup
from scipy.stats import beta

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from src.schemas.macro_schema import MacroMeetingSnapshot
from src.schemas.persona_schema import MemberPersona
from src.schemas.debate_schema import InitialStanceOutput, DeliberationOutput, FinalVoteOutput
from src.behavioral.debate_orchestrator import DebateOrchestrator
from src.persona_engine.extractor import PersonaExtractor, ROSTER_META
from src.rule_engine.engine import InstitutionalRuleEngine as Rule
from src.infra.transcript_logger import TranscriptLogger

def scores(pred, actual):
    tp=sum(len(p&a) for p,a in zip(pred,actual)); fp=sum(len(p-a) for p,a in zip(pred,actual)); fn=sum(len(a-p) for p,a in zip(pred,actual))
    return dict(tp=tp,fp=fp,fn=fn,precision=tp/max(tp+fp,1),recall=tp/max(tp+fn,1),f1=2*tp/max(2*tp+fp+fn,1))

class CaptureClient:
    def __init__(self, r3_token, r3_rate=0, r4_rate=0):
        self.r3_token=r3_token; self.r3_rate=r3_rate; self.r4_rate=r4_rate; self.prompts=[]
    async def generate(self, **kw):
        text=kw['user_prompt']; schema=kw['response_schema']
        mid=re.search(r'"member_id": "([^"]+)"',text).group(1)
        name=re.search(r'"member_name": "([^"]+)"',text)
        name=name.group(1) if name else mid
        if schema is InitialStanceOutput:
            parsed=schema(member_id=mid,member_name=name,proposed_rate_change_bps=0,proposed_stance='withdrawal_of_accommodation',key_rationale=f'PRIOR_{mid}')
            round_no=1
        elif schema is DeliberationOutput:
            round_no=int(re.search(r'"round_number": (\d)',text).group(1))
            parsed=schema(member_id=mid,round_number=round_no,current_rate_preference_bps=self.r3_rate if round_no==3 else 0,current_stance_preference='neutral' if round_no==3 else 'withdrawal_of_accommodation',rebuttal_or_critique=self.r3_token if round_no==3 else f'REBUTTAL_{mid}',open_to_compromise=True)
        else:
            round_no=4
            parsed=schema(member_id=mid,member_name=name,final_rate_vote_bps=self.r4_rate,final_stance_vote='withdrawal_of_accommodation',official_statement_rationale=f'FINAL_{mid}')
        self.prompts.append(dict(member_id=mid,round=round_no,user_prompt=text,system_prompt=kw['system_prompt']))
        return parsed.model_dump_json(), parsed

async def main():
    out={'environment':{'python':sys.version,'platform':platform.platform(),'root':str(ROOT),'no_provider_calls':True}}
    panel=pd.read_parquet(ROOT/'data/processed/macro_panel.parquet').sort_values('meeting_date')
    h=pd.read_csv(ROOT/'results/tables/holdout_meeting_by_meeting_comparison.csv')
    actual=[set(str(x).split(';')) if pd.notna(x) and x else set() for x in h.actual_dissenters]
    llm=[set(str(x).split(';')) if pd.notna(x) and x else set() for x in h.sim_dissenters]
    prior=[]
    for date in h.meeting_date:
        prior.append(set(panel[panel.meeting_date<date].iloc[-1].real_dissenters))
    out['baseline_comparison']={'n':len(h),'actual_rate_distribution':h.actual_rate_bps.value_counts().to_dict(),'actual_stance_distribution':h.actual_stance.value_counts().to_dict(),'pause_rate_accuracy':float((h.actual_rate_bps==0).mean()),'previous_stance_accuracy':float((h.actual_stance.to_numpy()==panel[panel.meeting_date.isin(h.meeting_date)].prev_stance.to_numpy()).mean()),'llm_dissent':scores(llm,actual),'always_varma':scores([{'jayanth_varma'}]*len(h),actual),'previous_meeting_dissent':scores(prior,actual),'independent_binomial_8of8_95pct_CI':[float(beta.ppf(.025,8,1)),1.0],'full_panel_n':len(panel),'calibration_n':int((panel.meeting_date<='2023-04-06').sum())}
    extractor=PersonaExtractor(output_dir=ROOT/'reviewer_evidence/unused_personas')
    leakage={}
    for mid in ROSTER_META:
        corpus=extractor.load_member_corpus(mid)
        leakage[mid]={'total':len(corpus),'holdout_dates':[d for d in corpus if d>'2023-04-06'],'full_score':extractor.analyze_member(mid)['calibrated_hawk_dove']}
    out['persona_corpus']=leakage
    # Separate calibration corpus in the copy; call extractor against that corpus only.
    caldir=ROOT/'reviewer_evidence/calibration_statements'; caldir.mkdir(exist_ok=True)
    for d in (ROOT/'data/processed/statements').iterdir():
        if d.is_dir() and d.name<='2023-04-06':
            (caldir/d.name).mkdir(exist_ok=True)
            for f in d.glob('*.txt'):
                (caldir/d.name/f.name).write_bytes(f.read_bytes())
    calex=PersonaExtractor(statements_dir=caldir,output_dir=ROOT/'reviewer_evidence/unused_personas')
    out['persona_calibration_only_scores']={mid:calex.analyze_member(mid)['calibrated_hawk_dove'] for mid in ROSTER_META}
    # Hash and statement provenance by corresponding meeting month, rather than any HTML.
    manifest=pd.read_csv(ROOT/'data/raw/manifest.csv'); hash_ok=0; stmt_ok=0; stmt_total=0; failed=[]
    for row in manifest.to_dict('records'):
        raw=ROOT/'data/raw/minutes_html'/row['local_filename']
        hash_ok+=hashlib.sha256(raw.read_bytes()).hexdigest()==row['sha256']
        normalized=' '.join(BeautifulSoup(raw.read_text(), 'html.parser').get_text().split())
        for stmt in (ROOT/'data/processed/statements').glob(f"{row['meeting_date']}*/*.txt"):
            stmt_total+=1
            valid=' '.join(stmt.read_text().split()) in normalized
            stmt_ok+=valid
            if not valid: failed.append(str(stmt.relative_to(ROOT)))
    out['local_provenance']={'raw_hash_matches':int(hash_ok),'manifest_n':len(manifest),'corresponding_month_statement_matches':int(stmt_ok),'statement_n':stmt_total,'failed':failed}
    # Recover holdout outcomes from saved transcript packages, reconcile final ballots.
    packages=[]
    for date in h.meeting_date:
        paths=list((ROOT/'runs').glob(f'*/transcripts/{date}/rep_1/meeting_outcome.json'))
        for path in paths:
            obj=json.loads(path.read_text()); votes=obj['member_votes']
            rates={v['member_id']:v['final_rate_vote_bps'] for v in votes}
            stances={v['member_id']:v['final_stance_vote'] for v in votes}
            item={'path':str(path.relative_to(ROOT)),'round_files':len(list(path.parent.glob('round_*.json'))),'fallbacks_count':obj.get('fallbacks_count'),'outcome_fields':sorted(obj),'matches_csv_rate':obj['rate_decision_bps']==int(h[h.meeting_date==date].sim_rate_bps.iloc[0])}
            try:
                item['reaggregate_rate_matches']=Rule.aggregate_rate_votes(rates,'shaktikanta_das').winning_action==obj['rate_decision_bps']
                item['reaggregate_stance_matches']=Rule.aggregate_stance_votes(stances,'shaktikanta_das').winning_action==obj['stance_decision']
            except Exception as e: item['aggregation_error']=str(e)
            packages.append(item)
    out['saved_holdout_packages']=packages
    personas=[MemberPersona(**yaml.safe_load(f.read_text())) for f in (ROOT/'personas/2020_2024_roster').glob('*.yaml') if f.stem!='mridul_saggar']
    snap=MacroMeetingSnapshot(**panel[panel.meeting_date=='2023-08-10'].iloc[0].to_dict())
    a=CaptureClient('ROUND3_SENTINEL_A',-50); b=CaptureClient('ROUND3_SENTINEL_B',50)
    oa=DebateOrchestrator(llm_client=a,logger=TranscriptLogger('independent_r3_a'))
    ob=DebateOrchestrator(llm_client=b,logger=TranscriptLogger('independent_r3_b'))
    da=await oa.run_meeting(snap,personas,'shaktikanta_das'); db=await ob.run_meeting(snap,personas,'shaktikanta_das')
    ap=[p['user_prompt'] for p in a.prompts if p['round']==4]; bp=[p['user_prompt'] for p in b.prompts if p['round']==4]
    out['round3_disconnect']={'six_r4_prompts_equal_after_r3_changes':ap==bp,'r3_sentinel_reaches_any_r4':any('ROUND3_SENTINEL' in p for p in ap+bp),'final_rates':[da.rate_decision_bps,db.rate_decision_bps],'final_stances':[da.stance_decision,db.stance_decision]}
    c=CaptureClient('ROUND3_ABLATED'); oc=DebateOrchestrator(llm_client=c,logger=TranscriptLogger('independent_ablation'))
    await oc.run_meeting(snap,personas,'shaktikanta_das',ablated_member_id='jayanth_varma')
    gov4=[p for p in c.prompts if p['round']==4 and p['member_id']=='shaktikanta_das'][0]['user_prompt']
    out['leaveout_infoflow']={'varma_prior_reaches_r2_r3':any('PRIOR_jayanth_varma' in p['user_prompt'] for p in c.prompts if p['round'] in (2,3)),'varma_final_rationale_reaches_governor_r4':'FINAL_jayanth_varma' in gov4}
    (ROOT/'reviewer_evidence/captured_prompts.json').write_text(json.dumps({'r3_a':a.prompts,'r3_b':b.prompts,'ablation':c.prompts},indent=2))
    # Accepted schema values 35/40 crash the aggregator used by the orchestrator.
    d=CaptureClient('R3',r4_rate=35); od=DebateOrchestrator(llm_client=d,logger=TranscriptLogger('independent_action35'))
    try:
        await od.run_meeting(snap,personas,'shaktikanta_das')
        out['action35_integration']='Unexpectedly accepted'
    except Exception as e: out['action35_integration']={'exception':type(e).__name__,'message':str(e)}
    malformed=FinalVoteOutput(member_id='wrong_id',member_name='wrong_name',final_rate_vote_bps='garbage',final_stance_vote='totally_invalid',official_statement_rationale='x')
    out['schema_corruption']={'accepted_id':malformed.member_id,'rate_garbage_coerced':malformed.final_rate_vote_bps,'invalid_stance_accepted':malformed.final_stance_vote,'fallback_triggered':malformed.fallback_triggered}
    out['ground_truth_prompt_filter']={'real_labels_in_snapshot':snap.real_rate_decision_bps is not None,'real_dissenters_in_macro_prompt':'jayanth_varma' in snap.to_prompt_text()}
    # Demonstrate the logger overwrite contract without modifying saved source traces.
    overwrite=TranscriptLogger('independent_overwrite')
    pa=overwrite.save_round_transcript('2023-08-10',1,1,'probe',{'condition':'baseline'})
    pb=overwrite.save_round_transcript('2023-08-10',1,1,'probe',{'condition':'shock'})
    out['logger_collision']={'same_path':pa==pb,'remaining_payload':json.loads(pa.read_text())}
    # Binary tie exhaustive check is legitimate within its stated restricted domain.
    tie_ok=0
    for higher in itertools.combinations(range(6),3):
        vv={f'm{i}':25 if i in higher else 0 for i in range(6)}
        ag=Rule.aggregate_rate_votes(vv,'m0'); tie_ok+=ag.winning_action==vv['m0'] and ag.tie_broken_by_governor
    out['binary_tie_probe']={'passed':tie_ok,'tested':20}
    (ROOT/'reviewer_evidence/probes.json').write_text(json.dumps(out,indent=2,default=str))
    print(json.dumps(out,indent=2,default=str))

if __name__=='__main__': asyncio.run(main())
