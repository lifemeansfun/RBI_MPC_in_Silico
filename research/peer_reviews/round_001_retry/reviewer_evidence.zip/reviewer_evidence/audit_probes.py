"""Controlled guard and budget mutation probes in independent evidence directories."""
import asyncio, hashlib, json, sys
from pathlib import Path
import pandas as pd
import yaml
from bs4 import BeautifulSoup
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from scripts.academic_integrity_guard import AcademicIntegrityGuard
from src.behavioral.debate_orchestrator import DebateOrchestrator
from src.infra.cost_governor import BudgetExceededError
from src.infra.transcript_logger import TranscriptLogger
from src.schemas.macro_schema import MacroMeetingSnapshot
from src.schemas.persona_schema import MemberPersona

async def main():
    out={}
    g=AcademicIntegrityGuard(); g.tables_dir=ROOT/'reviewer_evidence/mutated_tables'; g.tables_dir.mkdir(exist_ok=True)
    metrics=pd.read_csv(ROOT/'results/tables/holdout_validation_live_metrics.csv'); metrics.loc[0,'dissent_f1']=.01
    metrics.to_csv(g.tables_dir/'holdout_validation_live_metrics.csv',index=False)
    out['guard_wrong_f1_still_accepts_report']=g.check_invariant_3_table_report_concordance()
    g.runs_dir=ROOT/'reviewer_evidence/invalid_json_runs'
    dates=['2023-06-08','2023-08-10','2023-10-06','2023-12-08','2024-02-08','2024-04-05','2024-06-07','2024-08-08','2022-08-05']
    mids=['shaktikanta_das','michael_patra','rajiv_ranjan','shashanka_bhide','ashima_goyal','jayanth_varma']
    for d in dates:
        p=g.runs_dir/'dummy/transcripts'/d/'rep_1'; p.mkdir(parents=True,exist_ok=True)
        (p/'meeting_outcome.json').write_text('NOT JSON')
        for mid in mids:
            for n in range(1,5): (p/f'round_{n}_{mid}.json').write_text('NOT JSON')
    out['guard_invalid_json_transcript_chains_accepted']=g.check_invariant_2_transcript_provenance()
    class BudgetStop:
        calls=0
        async def generate(self,**kw):
            self.calls+=1
            raise BudgetExceededError('Independent probe: expenditure cap exceeded')
    c=BudgetStop(); o=DebateOrchestrator(llm_client=c,logger=TranscriptLogger('independent_budget_stop'))
    panel=pd.read_parquet(ROOT/'data/processed/macro_panel.parquet')
    snapshot=MacroMeetingSnapshot(**panel[panel.meeting_date=='2023-08-10'].iloc[0].to_dict())
    ps=[MemberPersona(**yaml.safe_load(p.read_text())) for p in (ROOT/'personas/2020_2024_roster').glob('*.yaml') if p.stem!='mridul_saggar']
    decision=await o.run_meeting(snapshot,ps,'shaktikanta_das')
    out['budget_stop']={'calls_after_raised_budget_error':c.calls,'completed_meeting':True,'fallbacks_count':decision.fallbacks_count}
    # Resolve the manifest's mislabeled September record by its official meeting title.
    manifest=pd.read_csv(ROOT/'data/raw/manifest.csv'); count=0; matches=0
    for row in manifest.to_dict('records'):
        month='2022-09' if row['prid']==54541 else row['meeting_date']
        html=ROOT/'data/raw/minutes_html'/row['local_filename']
        text=' '.join(BeautifulSoup(html.read_text(),'html.parser').get_text().split())
        for f in (ROOT/'data/processed/statements').glob(month+'*/*.txt'):
            count+=1; matches+=' '.join(f.read_text().split()) in text
    out['statement_provenance_title_corrected']={'matches':matches,'n':count,'manifest_correction':'prid=54541 title says September 28-30, 2022, although manifest month is 2022-10'}
    (ROOT/'reviewer_evidence/audit_probes.json').write_text(json.dumps(out,indent=2)); print(json.dumps(out,indent=2))

if __name__=='__main__': asyncio.run(main())
